# This JavaScript application generates a full year calendar and allows selection

It was designed for adaptation into the Page Drogher application (Process Servce Document Management)

It is stand-alone with calendar-by-year.html, but is intended to be included into a web app.

It is up to you to make all the necessary callbacks and connections.
