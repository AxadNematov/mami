tablebarchart
=============

Simple jQuery plugin to render a bar chart from existing <table> contents. Very easy to use.

=============

Please visit http://wiki.aiwsolutions.net/gQEYw for demonstration and full guideline.


