Make sure these boxes are checked before submitting your issue -- thank you!

- [ ] Check [FAQ](https://github.com/noraesae/perfect-scrollbar/wiki/FAQ)
- [ ] Search if there's already one reported in Issues
- [ ] Prepare a JSFiddle reproducing the issue
  - Perfect Scrollbar JSFiddle: https://jsfiddle.net/DanielApt/xv0rrxv3/
  - With jQuery: https://jsfiddle.net/DanielApt/gbfLazpx/
- [ ] Provide a page or source code where the issue can be checked
