Thank you very much for your contribution! Please make sure the followings
are checked.

- [ ] Read [CONTRIBUTING.md](../CONTRIBUTING.md)
- [ ] Run `gulp` to make sure it builds and lints successfully
- [ ] Provide the scenario this PR will address(some JSFiddles will be perfect)
  - Perfect Scrollbar JSFiddle: https://jsfiddle.net/DanielApt/xv0rrxv3/
  - With jQuery: https://jsfiddle.net/DanielApt/gbfLazpx/
- [ ] Refer to concerning issues if exist
