Congratulations on downloading the NoGray JavaScript Library. The NoGray JavaScript Library was developed to be a complete JavaScript framework that ease development of web apps and dynamic websites. The main goal is to maintain a backward compatible JavaScript library and continue to add new functionality.

How to Save the Files:
If this is a fresh download, make sure to download all the required files for any component. Upload the files to your server and follow the instructions on the API Documentation on how to use the scripts.

If you already downloaded the library and just adding extra files or components, merge the documents and folders in the zip files with what you have and upload them to your server.

Important Links:
 - Documentation: http://www.nogray.com/api/
 - Licensing: http://www.nogray.com/license.php
 - Contact us: http://www.nogray.com/contact.php

Copyright (c), All right reserved 
Gazing Design - http://www.NoGray.com