/// <reference path='../test.e2e.ts' />

'use strict';

describe('Axis padding', function() {
  beforeEach(function() {
    browser.get('test/e2e/axis_padding.html');
  });


});
