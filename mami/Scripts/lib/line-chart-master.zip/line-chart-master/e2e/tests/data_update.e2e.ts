/// <reference path='../test.e2e.ts' />

describe('Data update', function() {
  beforeEach(function() {
    browser.get('test/e2e/data_update.html');
  });
});
