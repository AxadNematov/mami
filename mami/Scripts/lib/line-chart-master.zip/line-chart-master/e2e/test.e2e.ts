/// <reference path='../typings/browser.d.ts' />
/// <reference path='../src/angularjs/LineChart.ts' />
