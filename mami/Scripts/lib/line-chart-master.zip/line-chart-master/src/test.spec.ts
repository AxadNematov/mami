/// <reference path='../typings/browser.d.ts' />
/// <reference path='./angularjs/LineChart.ts' />
