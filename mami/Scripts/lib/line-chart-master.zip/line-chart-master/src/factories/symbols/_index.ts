/// <reference path='HLine.ts' />
/// <reference path='VLine.ts' />
