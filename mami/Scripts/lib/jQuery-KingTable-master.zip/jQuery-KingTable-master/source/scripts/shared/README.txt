### README ###
This directory contains base functions, *mostly* business logic organized using 
R.js, and using Lodash library.

These functions are meant to be independent from any other library or web framework.

