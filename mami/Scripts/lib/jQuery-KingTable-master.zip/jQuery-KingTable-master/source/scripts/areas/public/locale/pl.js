_.extend(I.regional, {

  "pl": {
    "voc": {
      "Page": "Page",
      "of": "of",
      "Results": "Results",
      "ResultsPerPage": "Results per page",
      "Filters": "Filters",
      "NextPage": "Next",
      "PrevPage": "Previous",
      "FirstPage": "First",
      "LastPage": "Last",
      "Refresh": "Refresh",
      "NoResults": "There are no documents to display."
    },
  }
  
});